import boto3
import requests
import json
from requests_aws4auth import AWS4Auth
import logging
import time
import os
from boto3.dynamodb.types import TypeDeserializer

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Configuration
CHUNK_SIZE = 256
BEDROCK_MODEL_ID = 'cohere.embed-multilingual-v3'
OPENSEARCH_COLLECTION_ENDPOINT = "c3qceibouiy9tqnj94d6.ap-southeast-1.aoss.amazonaws.com"
OPENSEARCH_INDEX = "haire-vector-db-jobs-chunks-embeddings"

def get_aws_auth():
    try:
        session = boto3.Session()
        credentials = session.get_credentials().get_frozen_credentials()
        region = session.region_name or "ap-southeast-1"
        return AWS4Auth(
            credentials.access_key,
            credentials.secret_key,
            region,
            'aoss',
            session_token=credentials.token
        )
    except Exception as e:
        logger.error(f"Error getting AWS auth: {e}")
        raise e

def chunk_text(text, chunk_size):
    if not text:
        return []
    return [text[i:i + chunk_size] for i in range(0, len(text), chunk_size)]

def generate_embedding(bedrock_client, text_chunk):
    try:
        request_body = {
            "texts": [text_chunk],
            "input_type": "search_document"
        }
        response = bedrock_client.invoke_model(
            modelId=BEDROCK_MODEL_ID,
            contentType="application/json",
            accept="application/json",
            body=json.dumps(request_body)
        )
        result = json.loads(response['body'].read())
        return result['embeddings'][0]
    except Exception as e:
        logger.error(f"Error in generate_embedding: {e}")
        raise e

def delete_chunks_for_job(job_id, awsauth):
    logger.info(f"[DELETE] Removing all chunks for job_id={job_id}")
    query = {
        "query": {
            "term": {"job_id": job_id}
        }
    }
    try:
        url = f"https://{OPENSEARCH_COLLECTION_ENDPOINT}/{OPENSEARCH_INDEX}/_delete_by_query"
        res = requests.post(
            url,
            headers={"Content-Type": "application/json"},
            auth=awsauth,
            data=json.dumps(query),
            timeout=30
        )
        if res.status_code == 200:
            logger.info(f"      └─ [OpenSearch] ✅ Deleted existing chunks for job_id={job_id}")
        else:
            logger.warning(f"      └─ [OpenSearch] ❌ Failed to delete. Status={res.status_code}, Response={res.text}")
    except Exception as e:
        logger.error(f"      └─ [ERROR] Failed to delete chunks for job_id={job_id}: {e}")

def process_job_item(item, bedrock_client, awsauth):
    job_id = item.get('job_id')
    
    logger.info(f"[START] Processing job_id={job_id}")

    # Extract text from job fields
    required_skills = item.get('required_skills', '')
    requirements = item.get('requirements', '')
    responsibilities = item.get('responsibilities', '')
    
    descriptions = " ".join([required_skills, requirements, responsibilities]).strip()
    if not descriptions:
        logger.warning(f"[SKIP] No descriptions found for job_id={job_id}")
        return []

    logger.info(f"[INFO] Extracted total description length: {len(descriptions)} characters")

    chunks = chunk_text(descriptions, CHUNK_SIZE)
    logger.info(f"[INFO] Split into {len(chunks)} chunks")

    chunk_data_list = []
    for idx, chunk in enumerate(chunks):
        chunk_id = f"{job_id}_{idx}"
        logger.info(f"  └─ [Chunk {idx+1}/{len(chunks)}] chunk_id={chunk_id}, len={len(chunk)}")
        try:
            embedding = generate_embedding(bedrock_client, chunk)
            logger.info(f"      └─ [Embedding] Success, dim={len(embedding)}")
            chunk_data = {
                'chunk_id': chunk_id,
                'job_id': job_id,
                'chunk': chunk,
                'embedding': embedding
            }
            url = f"https://{OPENSEARCH_COLLECTION_ENDPOINT}/{OPENSEARCH_INDEX}/_doc"
            res = requests.post(
                url,
                headers={"Content-Type": "application/json"},
                auth=awsauth,
                data=json.dumps(chunk_data),
                timeout=30
            )
            if res.status_code == 201:
                logger.info(f"      └─ [OpenSearch] ✅ Chunk {chunk_id} written successfully")
                chunk_data_list.append(chunk_data)
            else:
                logger.error(f"      └─ [OpenSearch] ❌ Failed to write chunk {chunk_id}. Status={res.status_code}, Response={res.text}")
        except Exception as e:
            logger.error(f"      └─ [ERROR] Failed to process chunk {chunk_id}: {e}")
            continue

    logger.info(f"[DONE] Finished job_id={job_id}, total chunks={len(chunk_data_list)}\n")
    return chunk_data_list

def deserialize_dynamodb_item(dynamodb_item):
    deserializer = TypeDeserializer()
    return {k: deserializer.deserialize(v) for k, v in dynamodb_item.items()}

def lambda_handler(event, context):
    try:
        logger.info("=== Lambda triggered from DynamoDB Streams ===")
        bedrock_client = boto3.client('bedrock-runtime')
        awsauth = get_aws_auth()

        for record in event.get("Records", []):
            event_type = record.get("eventName")
            new_image = record.get("dynamodb", {}).get("NewImage")
            old_image = record.get("dynamodb", {}).get("OldImage")
            job_key = record.get("dynamodb", {}).get("Keys", {}).get("job_id", {}).get("S", "UNKNOWN")

            logger.info(f"[EVENT] Type={event_type}, Job ID={job_key}")

            if event_type == "INSERT":
                logger.info("[INSERT] NewImage: " + json.dumps(new_image, indent=2))
                item = deserialize_dynamodb_item(new_image)
                process_job_item(item, bedrock_client, awsauth)

            elif event_type == "MODIFY":
                logger.info("[MODIFY] OldImage: " + json.dumps(old_image, indent=2))
                logger.info("[MODIFY] NewImage: " + json.dumps(new_image, indent=2))
                old_item = deserialize_dynamodb_item(old_image)
                delete_chunks_for_job(old_item.get("job_id"), awsauth)
                item = deserialize_dynamodb_item(new_image)
                process_job_item(item, bedrock_client, awsauth)

            elif event_type == "REMOVE":
                logger.info("[REMOVE] OldImage: " + json.dumps(old_image, indent=2))
                old_item = deserialize_dynamodb_item(old_image)
                delete_chunks_for_job(old_item.get("job_id"), awsauth)

        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Stream events processed.'
            })
        }

    except Exception as e:
        logger.error(f"[FATAL] Lambda execution error: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
